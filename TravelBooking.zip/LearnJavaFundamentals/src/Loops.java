public class Loops {

	public static void main(String[] args) {
		//run at 50 go to 55
		//keep running until i is 55
		for(int i = 50; i <= 55; i++) {
			System.out.println(i *3);
		}
		
		
	}
	
	
	
}
