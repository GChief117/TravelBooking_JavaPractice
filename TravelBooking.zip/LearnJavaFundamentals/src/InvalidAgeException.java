
public class InvalidAgeException extends Exception{
	
	
	///make a constructor which takes into a string
	
	public InvalidAgeException(String message) {
		super(message);
	}
	
	
	public InvalidAgeException() {
		super();//super with no parameter
		
	}

}
