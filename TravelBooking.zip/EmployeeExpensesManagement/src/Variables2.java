
public class Variables2 {
	
	
	public static void main(String[] args) {
	
	//primiatives int, double, long, string
	//there are alternatives which start with them
	
	
	Double d1 = 1.2; //--this is also a class
	Integer i1 = 1; //--this is a class
	
	//the slight difference is
	
	
	//Double d2 = new Double(1.2);

}
}
