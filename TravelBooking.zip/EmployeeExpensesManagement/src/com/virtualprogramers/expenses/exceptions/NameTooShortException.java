package com.virtualprogramers.expenses.exceptions;

public class NameTooShortException extends Exception {

	public NameTooShortException() {
		// TODO Auto-generated constructor stub
	}

}
