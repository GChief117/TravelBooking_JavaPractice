/**
 * 
 */
package com.virtualprogramers.expenses.exceptions;

/**
 * @author gunnar_beck7
 *
 */
public class InvalidEmployeeException extends Exception{

	/**
	 * 
	 */
	public InvalidEmployeeException() {
		// TODO Auto-generated constructor stub
	}

}
