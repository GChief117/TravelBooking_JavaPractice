/**
 * 
 */
package com.virtualprogramers.expenses.exceptions;

/**
 * @author gunnar_beck7
 *
 */
public class EmployeeNotFoundException extends Exception{

	/**
	 * 
	 */
	public EmployeeNotFoundException() {
		// TODO Auto-generated constructor stub
	}

}
