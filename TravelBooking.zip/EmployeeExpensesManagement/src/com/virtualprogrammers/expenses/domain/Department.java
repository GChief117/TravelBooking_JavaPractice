package com.virtualprogrammers.expenses.domain;

public enum Department {
	//We have the keyword enum
	//we can have constant values
	//enter them and put them in commas
	
	//ex: all generic and consnat values which can be applied for every class
	
	//for example: 
	
	FINANCE, PERSONNEL, SALES, MARKETING, PRODUCTION
	
	//(NO ; NEEDED)
	
	

}
