package com.virtualprogrammers.expenses.domain;

public enum ExpenseType {
	
	
	TRAVEL, MEAL, ACCOMODATION, STATIONERY

}
