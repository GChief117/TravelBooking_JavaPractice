package com.virtualpairprogrammers.travelbooking;

public enum TravelTicketting {
	
	FIRST, SECOND, BUSINESS, CLUB

}
