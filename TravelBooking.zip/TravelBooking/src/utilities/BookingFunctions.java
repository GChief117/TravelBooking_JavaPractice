package utilities;

import com.virtualpairprogrammers.travelbooking.BusTicket;
import com.virtualpairprogrammers.travelbooking.TravelTicket;

public class BookingFunctions {
	
	
	public void bookTicket(TravelTicket ticket) {
		
	}
	
	
	public TravelTicket getTicket(int bookingRef) {
		//can return any bus ticket or other
		return new BusTicket(null, null, null, null, null, null);
		
		
	}

}
